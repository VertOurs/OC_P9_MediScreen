package fr.vertours.assessms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssessMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssessMsApplication.class, args);
	}

}
